```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
from sklearn import metrics
```


```python
path=r"https://raw.githubusercontent.com/AdiPersonalWorks/Random/master/student_scores%20-%20student_scores.csv"
df=pd.read_csv(path)
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(df.isnull().sum())
```

    Hours     0
    Scores    0
    dtype: int64
    


```python
X=df.drop('Scores', axis=1)
y=df['Scores']
plt.scatter(X,y)
plt.show()
```


    
![png](output_3_0.png)
    



```python
X = df.iloc[:, :-1].values  
y = df.iloc[:, 1].values  
from sklearn.model_selection import train_test_split  
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                            test_size=0.2, random_state=0) 
```


```python
from sklearn.linear_model import LinearRegression  
reg= LinearRegression()  
reg.fit(X_train, y_train) 
```




    LinearRegression()




```python
reg.score(X_test,y_test)
```




    0.9454906892105356




```python
line = reg.coef_*X+reg.intercept_
plt.scatter(X, y)
plt.plot(X, line);
plt.show()
```


    
![png](output_7_0.png)
    



```python
y_pred = reg.predict(X_test) 
df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})  
df 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20</td>
      <td>16.884145</td>
    </tr>
    <tr>
      <th>1</th>
      <td>27</td>
      <td>33.732261</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69</td>
      <td>75.357018</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30</td>
      <td>26.794801</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>60.491033</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_result=reg.predict([[9.25]])
print('If a Student studies for 9.25 Hours a day he will score: ',final_result)

```

    If a Student studies for 9.25 Hours a day he will score:  [93.69173249]
    


```python
from math import sqrt
print('Mean Absolute Error=', metrics.mean_absolute_error(y_test, y_pred))
print('Mean Squared Error=', metrics.mean_squared_error(y_test, y_pred))
print('Root Mean Squared Error =', np.sqrt(metrics.mean_squared_error(y_test,y_pred)))
```

    Mean Absolute Error= 4.183859899002975
    Mean Squared Error= 21.5987693072174
    Root Mean Squared Error = 4.6474476121003665
    


```python

```
